package pl.piomin.microservices.customer.model;

public enum CustomerType {

	INDIVIDUAL, COMPANY;
	
}
